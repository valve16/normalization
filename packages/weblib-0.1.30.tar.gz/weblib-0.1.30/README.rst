Weblib
======

.. image:: https://travis-ci.org/lorien/weblib.png?branch=master
    :target: https://travis-ci.org/lorien/weblib

.. image:: https://coveralls.io/repos/lorien/weblib/badge.svg?branch=master
    :target: https://coveralls.io/r/lorien/weblib?branch=master

.. image:: https://readthedocs.org/projects/weblib/badge/?version=latest
    :target: http://weblib.readthedocs.org/en/latest/


Weblib provides tools to solve typical tasks in web scraping:

* processing HTML
* handling text encodings
* controling repeating and parallel tasks
* parsing RSS/ATOM feeds
* preparing data for HTTP requests
* working with DOM tree
* working with text and numeral data
* list of common user agents
* cross-platform file locking
* operations with files and directories


Installation
============

Run:

.. code:: bash

    pip install -U weblib


Documentation
=============

Docs are incomplete. Most docs are auto-generated from modules/methods docstrings.
Check out docs here http://weblib.readthedocs.org/en/latest/
